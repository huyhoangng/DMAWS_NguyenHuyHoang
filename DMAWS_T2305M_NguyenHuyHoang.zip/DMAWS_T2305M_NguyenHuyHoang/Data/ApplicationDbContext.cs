using DMAWS_T2305M_NguyenHuyHoang.Models;
using Microsoft.EntityFrameworkCore;
namespace DMAWS_T2305M_NguyenHuyHoang.Data;

public class ApplicationDbContext: DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Project> Projects { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<ProjectEmployee> ProjectEmployees { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ProjectEmployee>()
            .HasKey(pe => new { pe.EmployeeId, pe.ProjectId });
    }
}