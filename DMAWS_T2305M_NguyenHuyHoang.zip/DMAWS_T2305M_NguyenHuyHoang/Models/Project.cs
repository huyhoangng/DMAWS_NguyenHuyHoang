using System.ComponentModel.DataAnnotations;

namespace DMAWS_T2305M_NguyenHuyHoang.Models;

public class Project
{
   
    public int ProjectId { get; set; }  

    [Required(ErrorMessage = "Project Name is required.")]
    [StringLength(150, MinimumLength = 2, ErrorMessage = "Project Name length must be between 2 and 150.")]
    public string ProjectName { get; set; }

    [Required(ErrorMessage = "Project Start Date is required.")]
    public DateTime ProjectStartDate { get; set; }

    public DateTime? ProjectEndDate { get; set; }  

    public virtual ICollection<ProjectEmployee> ProjectEmployees { get; set; }

   
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (ProjectEndDate.HasValue && ProjectEndDate <= ProjectStartDate)
        {
            yield return new ValidationResult("ProjectEndDate must be greater than ProjectStartDate.", new[] { nameof(ProjectEndDate) });
        }
    }
}