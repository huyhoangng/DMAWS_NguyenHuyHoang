using System.ComponentModel.DataAnnotations;

namespace DMAWS_T2305M_NguyenHuyHoang.Models;

public class Employee
{
  
    public int EmployeeId { get; set; }  

    [Required(ErrorMessage = "Employee Name is required.")]
    [StringLength(150, MinimumLength = 2, ErrorMessage = "Employee Name length must be between 2 and 150.")]
    public string EmployeeName { get; set; }

    [Required(ErrorMessage = "Employee Date of Birth is required.")]
    [DataType(DataType.Date)]
    public DateTime EmployeeDOB { get; set; }

    [Required(ErrorMessage = "Employee Department is required.")]
    public string EmployeeDepartment { get; set; }

    [EmailAddress(ErrorMessage = "Invalid Email Address.")]
    public string Email { get; set; } 

    public virtual ICollection<ProjectEmployee> ProjectEmployees { get; set; }

   
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (DateTime.Now.Year - EmployeeDOB.Year < 16)
        {
            yield return new ValidationResult("Employee must be over 16 years old.", new[] { nameof(EmployeeDOB) });
        }
    }
}